
	[The WI-FI Brute Forcer By TUX]

	- Thanks to TheBATeam, especially AACINI for making this UI possible.



	Help Page

	- help             : Prints this page
	- wifiscan         : Performs a WI-FI scan
	- interface	   : Select an interface for attack
	- attack           : Attacks on selected WI-FI


	[About Brute Forcer]
	
	- This program performs an "Online Attack" to the target WI-FI.
	- It's speed depends on your hardware.
	- Not % 100 accurate because of it's a brute force attack.
	- A big password file not included, you can create it with "keycombinator.cmd" or
	you can download from internet and rename it "passlist.txt" and paste it inside "BF_Files"
	- Because of Online Attack is so slow, big password lists are not recommended.
	- Your attack results are being written to "WIFI_Report.txt" inside "BF_Files"
	- Please, do not touch other files, it may cause malfunction!
	- "keycombinator.cmd" creates a list inside BF_Files with the name "passlist_raw.txt".
	You have to rename it to "passlist.txt"

	[Unsupported Char]

	- This means target SSID includes unsuported character by Command Prompt
	- To prevent program to malfunction, those SSIDs are banned.


	[Deleting Profile]

	- If you are trying to attack a network which you have already connected a network
	with the same name before, program deletes your previous profile.
	- Your previous password will be deleted.


	[MAC Spoofing]

	- MAC Spoofing is using a different MAC Address rather than the original one which your interface has.
	- It helps you to stay anonymous while attacking.
	- If you accidentaly disable your wi-fi interface, open cmd and type this
		netsh interface set interface name="Wi-Fi" admin=Enabled

	- If you have multiple Wi-Fi interfaces, it may be Wi-Fi 2 or etc. (Wi-Fi 3,4,5...)




	