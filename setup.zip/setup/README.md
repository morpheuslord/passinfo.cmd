# Batch-WI-FI-Brute-Forcer
This project is based upon the trick that, **how to hack WI-FI with CMD**. The main purpose behind, creating **wifi hacking tool** with cmd tool is to make everyone aware that how easy it is to break a simple password. And, motivate them to keep some complex passwords – to keep them protected against it.

![](https://i1.wp.com/www.thebateam.org/wp-content/uploads/2020/04/WifiBruteForcer_intro.gif?fit=718%2C561&ssl=1)

# ABOUT PASSWORD CRACKING WITH CMD
Some of you may know the concept of **Brute Forcing**, but I will explain it for the ones who don’t know. In case, you are already familiar with it – you are free to skip this part (although, you will definitely learn something new from it).

There are 3 types of attacks:

1. BRUTE FORCE ATTACK FOR PASSWORD CRACKING
This type of attacks are simply try all possible combinations. And, it seems weird and impractical at first. But, as computers can do billion of **calculations** per second – so, it is not that much impractical to try out everything. The only problem is – it needs time; HELL LOT OF TIME!

2. DICTIONARY ATTACK
In this type of password **hacking attack** – again we try all **passwords**, but this time they are stored in a text file that you have given to the program. So, the program only refers to a few password combinations to verify the accessibility of the network.

3. THE MASKED ATTACK
In masked attack; we apply a bit different approach – Here the concept is to try all possible **combinations** in a way programmer defines. And, in this attack **hackers** combine some social engineering to make it better and less hard for the dumb computer.

```For example: Try all birthdates or phone numbers.
```

# HOW TO HACK WIFI WITH CMD? – THE ALGORITHM
So, basically – In this part, you’ll know how it is possible to hack wifi password with CMD and it is not another fake trick to fool you guys! Let’s have a look at the basic parts of this main project:

WI-FI Brute Forcer has 4 main parts:
1.Interface Detection
2.Interface Selection
3.WI-FI Scanning and Selecting
4.Attacking

![](https://i2.wp.com/www.thebateam.org/wp-content/uploads/2020/04/bf_thebateam_1-1.jpg?w=521&ssl=1)

Program detects your WI-FI hardware and if it finds multiple interfaces, it will ask you to select one.
You can select it later on but it is required for scanning and attacking.

![](https://i0.wp.com/www.thebateam.org/wp-content/uploads/2020/04/bf_thebateam_2-1.jpg?w=541&ssl=1)

Then you should perform a WI-FI scan to select target.

![](https://i0.wp.com/www.thebateam.org/wp-content/uploads/2020/04/bf_thebateam_3-1.jpg?w=556&ssl=1)


Here we go! Start the attacking process and sit back until it finishes.
I have provided you 50 most common passwords but you can also add your own password lists.

# VIDEO DEMO: WIFI HACKING WITH CMD IN ACTION
Small video demo from the creator himself – showing the project in action. You can also download the project files from the bottom of this post and try your hands on it. (Make sure to read the Disclaimer twice before that)

Youtube Link- <a href="https://www.youtube.com/watch?v=l1X9leGySBU">Quick Demo by TUX!</a>

# THAT EXTRA MILE – IS ALWAYS GOOD! 

![](https://i2.wp.com/www.thebateam.org/wp-content/uploads/2020/04/bf2.png?w=540&ssl=1)

I have provided you a **key combinator** app that can create random passwords with the information you gave.

# THEBATEAM VIDEO REVIEW

Youtube Link- <a href="https://youtu.be/80lYo4Hhmk4">Working Review – Demo video!</a>

[Read Full Article](https://www.thebateam.org/2020/04/hack-wifi-with-cmd/)
